package main;

import "fmt"

	func add(x int, y int) (result int){
		result = x + y
		return 
	}
		


func main(){
	//creating variables

	// var name = "Ames"
	var age int32 = 78
	var isCool = true
	isCool = false

	//shorthand

	name := "Ames"
	size := 34.5

	fmt.Println(name, age, isCool)
	fmt.Printf("%T\n", name)
	fmt.Printf("%T\n", age)
	fmt.Printf("%T\n", isCool)
	fmt.Printf("%T\n", size)

	fmt.Println(add(2,3))
}