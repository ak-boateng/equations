# equations
This project contains mathematical equations implemented using numpy.
